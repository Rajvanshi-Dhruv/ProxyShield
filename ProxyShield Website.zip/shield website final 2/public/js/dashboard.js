// Check connection status when the page loads
window.addEventListener("load", () => {
  fetch("/status")
    .then(res => res.json())
    .then(data => {
      document.getElementById("status").innerText = `Status: ${data.message}`;
    });
});

function connect() {
  const server = document.getElementById("server").value;
  fetch("/connect", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `server=${server}`
  }).then(res => res.json()).then(data => {
    document.getElementById("status").innerText = `Status: ${data.message}`;
  });
}

function disconnect() {
  fetch("/disconnect", {
    method: "POST"
  }).then(res => res.json()).then(data => {
    document.getElementById("status").innerText = `Status: ${data.message}`;
  });
}

// No need to reset VPN status when going to home page
document.getElementById("backToHomeBtn").addEventListener("click", function() {
  window.location.href = "/home"; // Simply navigate to home without resetting VPN status
});
