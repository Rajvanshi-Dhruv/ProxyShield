document.getElementById("vpnServersBtn").addEventListener("click", function() {
    // You can fetch data for the servers here, instead of navigating directly
    fetch("/dashboard")  // Assuming /servers is your API endpoint that returns server data
      .then(response => response.json())
      .then(data => {
        // Assuming data.servers is an array of server names
        const serverListContainer = document.getElementById("serverListContainer");
  
        // Clear any previous content
        serverListContainer.innerHTML = "<h2>VPN Servers:</h2>";
  
        const serverList = document.createElement("ul");
  
        data.servers.forEach(server => {
          const listItem = document.createElement("li");
          listItem.textContent = server;
          serverList.appendChild(listItem);
        });
  
        serverListContainer.appendChild(serverList);
  
        // Optionally, change the page title or any other UI element
        document.title = "VPN Servers";
      })
      .catch(error => {
        console.error("Error fetching VPN servers:", error);
      });
  });
  