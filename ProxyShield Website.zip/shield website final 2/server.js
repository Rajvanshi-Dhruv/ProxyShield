const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const path = require("path");
const fs = require("fs");
const { spawn, exec } = require("child_process");

const isAdmin = require("is-admin").default;
isAdmin().then(admin => console.log("Running as admin?", admin));

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: "proxyshield-secret",
  resave: false,
  saveUninitialized: true
}));
app.use("/css", express.static(path.join(__dirname, "public/css")));
app.use("/js", express.static(path.join(__dirname, "public/js")));

// In-memory users array (for demo)
const users = [];

// Pages
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "views/index.html")));
app.get("/home", (req, res) => res.sendFile(path.join(__dirname, "views/home.html")));
app.get("/login", (req, res) => res.sendFile(path.join(__dirname, "views/login.html")));
app.get("/signup", (req, res) => res.sendFile(path.join(__dirname, "views/signup.html")));
app.get("/dashboard", (req, res) => res.sendFile(path.join(__dirname, "views/dashboard.html")));
app.get("/ipinfo", (req, res) => res.sendFile(path.join(__dirname, "views/ipinfo.html")));

// Signup/Login
app.post("/signup", (req, res) => {
  const { name, email, password } = req.body;
  users.push({ name, email, password });
  res.redirect("/login");
});

app.post("/login", (req, res) => {
  const { name, password } = req.body;
  const user = users.find(u => u.name === name && u.password === password);
  if (user) res.redirect("/home");
  else res.send("Invalid login. <a href='/login'>Try again</a>");
});

// VPN Connect
app.post("/connect", (req, res) => {
  const server = req.body.server;
  if (!server) return res.status(400).json({ message: "Server not specified" });

  const vpnConfigPath = 'D:\\shield website final 2\\vpn_configs';
  const configPath = path.join(vpnConfigPath, `${server}.ovpn`);

  if (!fs.existsSync(configPath)) {
    return res.status(404).json({ success: false, message: "Config file not found." });
  }

  const openvpnPath = 'C:\\Program Files\\OpenVPN\\bin\\openvpn.exe';
  const openvpn = spawn(openvpnPath, ['--config', configPath]);

  openvpn.on('spawn', () => {
    fs.writeFileSync('vpn_pid.txt', openvpn.pid.toString(), 'utf8');
    req.session.vpnStatus = "connected";
    req.session.save();
    console.log("VPN connected");
  });

  openvpn.stdout.on('data', (data) => console.log(`stdout: ${data}`));
  openvpn.stderr.on('data', (data) => console.error(`stderr: ${data}`));

  openvpn.on('close', (code) => {
    req.session.vpnStatus = "disconnected";
    req.session.save();
    console.log(`OpenVPN exited with code ${code}`);
  });

  res.json({ success: true, message: `Connecting to ${server}...` });
});

// VPN Disconnect
app.post("/disconnect", (req, res) => {
  if (fs.existsSync("vpn_pid.txt")) {
    const pid = fs.readFileSync("vpn_pid.txt", "utf8");
    exec(`taskkill /PID ${pid} /F`, (err) => {
      if (err) return res.status(500).json({ success: false, message: "Failed to disconnect" });
      fs.unlinkSync("vpn_pid.txt");
      req.session.vpnStatus = "disconnected";
      req.session.save();
      res.json({ success: true, message: "Disconnected from VPN" });
    });
  } else {
    req.session.vpnStatus = "disconnected";
    req.session.save();
    res.json({ success: false, message: "Already disconnected" });
  }
});

// VPN Status
app.get("/status", (req, res) => {
  const pidExists = fs.existsSync("vpn_pid.txt");
  const sessionStatus = req.session.vpnStatus || "disconnected";

  if (pidExists) {
    const pid = fs.readFileSync("vpn_pid.txt", "utf8");
    exec(`tasklist /FI "PID eq ${pid}"`, (err, stdout) => {
      const isRunning = stdout.includes(pid);
      req.session.vpnStatus = isRunning ? "connected" : "disconnected";
      res.json({
        connected: isRunning,
        message: isRunning ? "VPN is connected" : "VPN is disconnected"
      });
    });
  } else {
    req.session.vpnStatus = "disconnected";
    res.json({ connected: false, message: "VPN is disconnected" });
  }
});

// Optional: Reset manually
app.get("/reset-vpn-status", (req, res) => {
  if (fs.existsSync("vpn_pid.txt")) {
    const pid = fs.readFileSync("vpn_pid.txt", "utf8");
    exec(`taskkill /PID ${pid} /F`, (err) => {
      if (!err) fs.unlinkSync("vpn_pid.txt");
      req.session.vpnStatus = "disconnected";
      req.session.save();
      res.json({ success: true, message: "VPN status reset" });
    });
  } else {
    req.session.vpnStatus = "disconnected";
    req.session.save();
    res.json({ success: true, message: "VPN already disconnected" });
  }
});

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
