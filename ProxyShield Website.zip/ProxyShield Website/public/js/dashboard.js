function connect() {
  const server = document.getElementById("server").value;
  fetch("/connect", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `server=${server}`
  }).then(res => res.json()).then(data => {
    document.getElementById("status").innerText = `Status: ${data.message}`;
  });
}

function disconnect() {
  fetch("/disconnect", {
    method: "POST"
  }).then(res => res.json()).then(data => {
    document.getElementById("status").innerText = `Status: ${data.message}`;
  });
}