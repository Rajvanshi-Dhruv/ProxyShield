const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json()); // for JSON POST bodies
app.use("/css", express.static(path.join(__dirname, "public/css")));
app.use("/js", express.static(path.join(__dirname, "public/js")));

const users = [];

// Pages
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "views/index.html")));
app.get("/login", (req, res) => res.sendFile(path.join(__dirname, "views/login.html")));
app.get("/signup", (req, res) => res.sendFile(path.join(__dirname, "views/signup.html")));
app.get("/dashboard", (req, res) => res.sendFile(path.join(__dirname, "views/dashboard.html")));

// Signup/Login
app.post("/signup", (req, res) => {
  const { name, email, password } = req.body;
  users.push({ name, email, password });
  res.redirect("/login");
});

app.post("/login", (req, res) => {
  const { name, password } = req.body;
  const user = users.find(u => u.name === name && u.password === password);
  if (user) res.redirect("/dashboard");
  else res.send("Invalid login. <a href='/login'>Try again</a>");
});

// VPN Connect
app.post("/connect", (req, res) => {
  const server = req.body.server;
  if (!server) return res.status(400).json({ message: "Server not specified" });

  const vpnConfigPath = 'D:\\shield website final 2\\vpn_configs'; // Update to your directory

  // Function to handle VPN connection
  function connectVPN(server) {
    const configPath = path.join(vpnConfigPath, `${server}.ovpn`); // Combine with server name (e.g., South_korea_1.ovpn)

    // Check if the config file exists
    if (!fs.existsSync(configPath)) {
      console.error("Config not found: ", configPath);
      return;
    }
    const openvpnPath = 'C:\\Program Files\\OpenVPN\\bin\\openvpn.exe'; // Full path to OpenVPN executable
    const openvpn = spawn('runas', ['/user:Administrator', openvpnPath, '--config', configPath]);
    
    openvpn.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`);
    });

    openvpn.stderr.on('data', (data) => {
      console.error(`stderr: ${data}`);
    });

    openvpn.on('close', (code) => {
      console.log(`OpenVPN process exited with code ${code}`);
    });
  }

  connectVPN(server); // Call the function to start the VPN connection

  res.json({ message: `Connecting to ${server}...` });
});

// VPN Disconnect
app.post("/disconnect", (req, res) => {
  if (fs.existsSync("vpn_pid.txt")) {
    const pid = fs.readFileSync("vpn_pid.txt", "utf8");
    exec(`taskkill /PID ${pid} /F`, (err) => {
      if (err) return res.status(500).json({ message: "Failed to disconnect" });
      fs.unlinkSync("vpn_pid.txt");
      res.json({ message: "Disconnected from VPN" });
    });
  } else {
    res.json({ message: "Already disconnected" });
  }
});

// VPN Status
app.get("/status", (req, res) => {
  if (fs.existsSync("vpn_pid.txt")) {
    const pid = fs.readFileSync("vpn_pid.txt", "utf8");
    exec(`tasklist /FI "PID eq ${pid}"`, (err, stdout) => {
      if (stdout.includes(pid)) {
        res.json({ connected: true });
      } else {
        res.json({ connected: false });
      }
    });
  } else {
    res.json({ connected: false });
  }
});

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
